import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/events")
public class EventServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Event> events = new ArrayList<>();
        try {
            // Établir la connexion à la base de données
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "aina", "nirintsoa");

            // Exécuter la requête SQL pour récupérer les événements
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Evenements");

            // Parcourir le résultat et ajouter les événements à la liste
            while (rs.next()) {
                Event event = new Event();
                event.setTitle(rs.getString("titre"));
                event.setDescription(rs.getString("description"));
                // Ajouter d'autres champs d'événement si nécessaire
                events.add(event);
            }

            // Fermer la connexion et les ressources
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Ajouter la liste des événements à l'objet de requête
        request.setAttribute("events", events);

        // Rediriger vers la page JSP pour afficher les événements
        request.getRequestDispatcher("plage.jsp").forward(request, response);
    }
}