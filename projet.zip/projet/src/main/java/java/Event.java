package java;
public class Event {
    private String title;
    private String description;

    // Ajoutez d'autres champs d'événement si nécessaire

    // Getter et Setter pour le titre
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Getter et Setter pour la description
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Ajoutez d'autres getters et setters si nécessaire
}
