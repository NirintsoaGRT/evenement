

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Statement;
import com.mysql.cj.jdbc.Driver;
import java.Event;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class selecta extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public selecta() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Event> events = new ArrayList<>();

        // Récupérer les événements depuis la base de données
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "aina", "nirintsoa");
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM Evenements");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Event event = new Event();
                event.setTitle(rs.getString("titre"));
                event.setDescription(rs.getString("description"));
                // Ajoutez d'autres attributs de l'événement si nécessaire
                events.add(event);
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Ajouter les événements à l'attribut de la requête
        request.setAttribute("events", events);

        // Renvoyer la requête au JSP
        request.getRequestDispatcher("plage.jsp").forward(request, response);
    }
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	    String titre = request.getParameter("titre");
        String description = request.getParameter("description");
        String date = request.getParameter("date");
        String heure = request.getParameter("heure");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event", "aina", "nirintsoa");
            PreparedStatement pst = con.prepareStatement("INSERT INTO Evenements (titre, description, date, heure) VALUES (?, ?, ?, ?)");
            pst.setString(1, titre);
            pst.setString(2, description);
            pst.setString(3, date);
            pst.setString(4, heure);
            pst.executeUpdate();
            pst.close();
            con.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        response.sendRedirect("tableauBRD.jsp");
    }
}

